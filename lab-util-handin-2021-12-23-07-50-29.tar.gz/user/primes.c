#include "kernel/types.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
    int p0[2];
    int pid;
    pipe(p0);
    pid = fork();
    if ( pid > 0){
        close(p0[0]);
        for (int i = 2; i < 36; i++){
            write(p0[1], &i, sizeof(i));
        }
        close(p0[1]);
        wait(0);
        exit(0);
    }else{
        close(p0[1]);
        int p1[2];
        int hasPiped = 0;
        int prime;
        if(read(p0[0], &prime, sizeof(prime)) == sizeof(int)){// prime = 2
            printf("prime %d\n", prime);
        }
        int n;
        while(read(p0[0], &n, sizeof(n)) != 0){
            if (n % prime != 0){
                if (!hasPiped){
                    pipe(p1);
                    hasPiped = 1;
                }
                write(p1[1], &n, sizeof(n));
            }
        }
        close(p0[0]);
        pid = fork();
        if (pid > 0){
            close(p1[1]);
            close(p1[0]);
            wait(0);
        }else{
            hasPiped = 0;
            close(p1[1]);
            if(read(p1[0], &prime, sizeof(prime)) == sizeof(int)){// prime = 3
                printf("prime %d\n", prime);
            }
            while(read(p1[0], &n, sizeof(n)) != 0){
                if (n % prime != 0){
                    if (!hasPiped){
                        pipe(p0);
                        hasPiped = 1;
                    }
                    write(p0[1], &n, sizeof(n));
                }
            }
            close(p1[0]);
            pid = fork();
            if (pid > 0){
                close(p0[1]);
                close(p0[0]);
                wait(0);
            }else{
                hasPiped = 0;
                close(p0[1]);
                if(read(p0[0], &prime, sizeof(prime)) == sizeof(int)){// prime = 3
                    printf("prime %d\n", prime);
                }
                while(read(p0[0], &n, sizeof(n)) != 0){
                    if (n % prime != 0){
                        printf("prime %d\n", n);
                    }
                }
                close(p0[0]);
            }
        }
        
        exit(0);
    }
    
}