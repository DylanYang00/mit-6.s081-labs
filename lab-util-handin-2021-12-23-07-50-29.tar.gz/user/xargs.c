#include "kernel/types.h"
#include "kernel/param.h"
#include "user/user.h"

/**
 * @brief Get a line from stdin
 * read one character at a time until a '\n' or EOF is met.
 * @param buf the line of input returned into this parameter
 * @return 0 as EOF is met, 1 as '\n' is met
 */
int getLine(char *buf)
{
    int i = 0;
    while (read(0, buf + i, 1) != 0)
    {
        if (buf[i] == '\n')
        {
            buf[i] = 0;
            return 1;
        }
        i++;
    }
    buf[i] = 0;
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        fprintf(2, "usage: xargs command...\n");
        exit(1);
    }
    //copy arguments of xargs into argvs
    char *argvs[MAXARG];
    int i = 0;
    while (argv[i + 1] != 0)
    {
        argvs[i] = argv[i + 1];
        i++;
    }
    //get a line from stdin, fork and exec it
    char buf[50];
    int pid;
    while (getLine(buf) == 1)
    {
        pid = fork();
        if (pid < 0)
        {
            fprintf(2, "fork failed...\n");
            exit(1);
        }
        else if (pid > 0)
        {
            wait(0);
        }
        else
        {
            argvs[i] = buf;
            exec(argvs[0], argvs);
            fprintf(2, "exec failed...\n");
            exit(1);
        }
    }
    if (buf[0] != 0)
    {
        pid = fork();
        if (pid < 0)
        {
            fprintf(2, "fork failed...\n");
            exit(1);
        }
        else if (pid > 0)
        {
            wait(0);
        }
        else
        {
            argvs[i] = buf;
            exec(argvs[0], argvs);
            fprintf(2, "exec failed...\n");
            exit(1);
        }
    }
    exit(0);
}
