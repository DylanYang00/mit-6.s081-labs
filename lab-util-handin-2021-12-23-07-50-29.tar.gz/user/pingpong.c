#include "kernel/types.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
    int p1[2];
    int p2[2];
    if(pipe(p1) < 0){
        fprintf(2, "pipe failed !\n");
        exit(1);
    }
    if(pipe(p2) < 0){
        fprintf(2, "pipe failed !\n");
        exit(1);
    }

    int pid = fork();
    if (pid < 0){
        fprintf(2, "fork failed !\n");
        exit(1);
    }else if (pid > 0){ // parent
        // parent write to p1, and read from p2
        close(p1[0]);
        close(p2[1]);
        char buf[1];
        if(write(p1[1], "Y", 1) < 1){
            fprintf(2, "parent write to pipe failed !\n");
            exit(1);
        }
        if(read(p2[0], buf, 1) < 1){
            fprintf(2, "parent read from pipe failed !\n");
            exit(1);
        }
        printf("%d: received pong\n", getpid());
        exit(0);

    }else{ //child
        // child read from p1, and write to p2
        close(p1[1]);
        close(p2[0]);
        char buf[1];
        if(read(p1[0], buf, 1) < 1){
            fprintf(2, "child read from pipe failed !\n");
            exit(1);
        }
        printf("%d: received ping\n", getpid());
        if(write(p2[1], "Y", 1) < 1){
            fprintf(2, "child write to pipe failed !\n");
            exit(1);
        }
        exit(0);
    }
    
}